//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//

import UIKit

final class ___VARIABLE_sceneName___ViewController: UIViewController {
    
    // MARK: - external dependencies

    private let viewModel: ___VARIABLE_sceneName___ViewModelProtocol
    
    // MARK: - UI properties
    
    
    
    // MARK: - init
    
    init(viewModel: ___VARIABLE_sceneName___ViewModelProtocol) {
        self.viewModel = viewModel
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // MARK: - life cycle

    override func viewDidLoad() {
        super.viewDidLoad()
        setup()
    }
    
    // MARK: - setup UI
    
    private func setup() {
        addViews()
        setupViews()
        setupConstraints()
    }
        
    private func addViews() {
        
    }
    
    private func setupViews() {
        
    }
        
    private func setupConstraints() {
        
    }
        
    // MARK: - private methods

    
    
    // MARK: - objc methods
    
    
    
}
