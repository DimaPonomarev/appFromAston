//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//

import Foundation

protocol ___VARIABLE_sceneName___ViewModelProtocol: AnyObject {
    
}

class ___VARIABLE_sceneName___ViewModel: ___VARIABLE_sceneName___ViewModelProtocol {
    
    // MARK: - external properties
    
    private let coordinator: Coordinator
    
    // MARK: - data variables
    
    
    
    // MARK: - private variables
    
    
    
    // MARK: - init
    
    init(coordinator: Coordinator) {
        self.coordinator = coordinator
    }
    
    // MARK: - delegate methods
    
    
    
    // MARK: - private methods
    
    
    
}

